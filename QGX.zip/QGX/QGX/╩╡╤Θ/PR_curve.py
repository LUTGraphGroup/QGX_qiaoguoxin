def main2():
    # 读取数据
    kendall = pd.read_excel('out/imprecision.xlsx', sheet_name='USAir',header=None)  # header=0删除了第一行
    # print(kendall)
    Y = []
    for i in range(kendall.shape[0]):  # 遍历行
        Y1 = []
        for j in range(kendall.shape[1]):  # 遍历列
            Y1.append(kendall[j][i])
            # Y1.append(kendall.loc[i, kendall.columns[j]])
        Y.append(Y1)
    print("Number of rows in kendall data:", kendall.shape[0])
    print("Number of columns in kendall data:", kendall.shape[1])
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0.01, 0.1, 10)  #感染率
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="gold", linewidth=2, linestyle="-", marker='s',
             markersize=6, markerfacecolor='gold', label=r"BC")
    plt.plot(X, Y[2], color="darkorange", linewidth=2, linestyle="-",
             marker='p', markersize=6, markerfacecolor='darkorange', label=r"KS")
    plt.plot(X, Y[3], color="forestgreen", linewidth=2, linestyle="-",
             marker='*', markersize=6, markerfacecolor='forestgreen', label=r"QLC")
    plt.plot(X, Y[4], color="dodgerblue", linewidth=2, linestyle="-",
             marker='H', markersize=6, markerfacecolor='dodgerblue', label=r"GLS")
    plt.plot(X, Y[5], color="blue", linewidth=2, linestyle="-",
             marker='^', markersize=6, markerfacecolor='blue', label=r"ALSI")
    plt.plot(X, Y[6], color="darkorchid", linewidth=2, linestyle="-",
             marker='x', markersize=6, markerfacecolor='darkorchid', label=r"LC")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"NLGSC")
    # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

            '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("$p$", font)
    plt.ylabel("$\\varepsilon$", font)
    plt.title(r'USAir', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.01)  # 以每0.05显示
    y_major_locator = MultipleLocator(0.02)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0.005, 0.105)
    plt.ylim(-0.003, 0.2)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    # front是标签属性：包括字体、大小等
    # font1 = {'font.family': 'Times New Roman',
    #          'mathtext.fontset':'stix',
    #         'font.weight': 'bold',
    #         'font.size': 13,
    #         }#normal,bold,heavy,black
    # plt.rcParams.update(font1)#设置运行配置参数 rcParams （runtime configuration parameters）
    # with plt.rc_context(font1):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

# 添加局部放大的子图
axins = inset_axes(ax, width="50%", height="45%", loc='lower left', bbox_to_anchor=(0.085, 0.06, 0.9, 0.45),
                   bbox_transform=ax.transAxes)  # 这一行可以尝试去除边框
# ax.indicate_inset_zoom(axins, edgecolor="None", alpha=0)  # 禁用箭头和边框
plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
         marker='d', markersize=6, markerfacecolor='r', label=r"DC")
plt.plot(X, Y[1], color="gold", linewidth=2, linestyle="-", marker='s',
         markersize=6, markerfacecolor='gold', label=r"BC")
plt.plot(X, Y[2], color="darkorange", linewidth=2, linestyle="-",
         marker='p', markersize=6, markerfacecolor='darkorange', label=r"KS")
plt.plot(X, Y[3], color="forestgreen", linewidth=2, linestyle="-",
         marker='*', markersize=6, markerfacecolor='forestgreen', label=r"QLC")
plt.plot(X, Y[4], color="dodgerblue", linewidth=2, linestyle="-",
         marker='H', markersize=6, markerfacecolor='dodgerblue', label=r"GLS")
plt.plot(X, Y[5], color="blue", linewidth=2, linestyle="-",
         marker='^', markersize=6, markerfacecolor='blue', label=r"ALSI")
plt.plot(X, Y[6], color="darkorchid", linewidth=2, linestyle="-",
         marker='x', markersize=6, markerfacecolor='darkorchid', label=r"LC")
plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
         marker='o', markersize=6, markerfacecolor='k', label=r"NLGSC")

# 设定子图的显示范围
x1, x2, y1, y2 = 0.01, 0.11, 0, 0.006
axins.set_xlim(x1, x2)
axins.set_ylim(y1, y2)
plt.savefig('E:\paper\code\slh\photo\im_UASir.pdf', format='pdf',
            dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格ox_inches = 'tight'去掉空白
plt.show()