from sklearn.metrics import auc
import numpy as np
import matplotlib.pyplot as plt

# Load data
ymips_mean_fpr0 = np.loadtxt('fpr_values.csv', delimiter=',')
ymips_mean_tpr0 = np.loadtxt('tpr_DeepEP.csv', delimiter=',')
ydip_mean_fpr0 = np.loadtxt('MBIEP_fpr.csv', delimiter=',')
ydip_mean_tpr0 = np.loadtxt('MBIEP_tpr.csv', delimiter=',')
mean_fpr0 = np.loadtxt('mean_fpr.csv', delimiter=',')
mean_tpr0 = np.loadtxt('mean_tpr.csv', delimiter=',')

# Calculate AUC
ymips_mean_auc0 = auc(ymips_mean_fpr0, ymips_mean_tpr0)
ydip_mean_auc0 = auc(ydip_mean_fpr0, ydip_mean_tpr0)
mean_auc0 = auc(mean_fpr0, mean_tpr0)

# Set line width
lw = 2

# Create and save the first ROC curve
plt.figure(figsize=(6, 6))
plt.plot(mean_fpr0, mean_tpr0, '--', color='#5CC4AA', lw=lw,
         label='ROC our method (AUC = %0.4f)' % mean_auc0)
plt.plot(ymips_mean_fpr0, ymips_mean_tpr0, '--', color='#f2cf44', lw=lw,
         label='ROC DeepEP (AUC = %0.4f)' % ymips_mean_auc0)
plt.plot(ydip_mean_fpr0, ydip_mean_tpr0, '--', color='#fd9490', lw=lw,
         label='ROC MBIEP (AUC = %0.4f)' % ydip_mean_auc0)

plt.plot([0, 1], [0, 1], color='grey', linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve')
plt.legend(loc="lower right")
plt.tight_layout()
plt.axis('square')
plt.savefig("ROC.pdf", dpi=300)
plt.show()

precision_new = np.loadtxt('Precision_1.txt', delimiter=',')
recall_new = np.loadtxt('Recall_1.txt', delimiter=',')
precision_new2 = np.loadtxt('precision_deep.txt', delimiter=',',skiprows=1)
recall_new2 = np.loadtxt('recall_deep.txt', delimiter=',',skiprows=1)
precision_new3 = np.loadtxt('precision_MBIEP.txt', delimiter=',')
recall_new3 = np.loadtxt('recall_MBIEP.txt', delimiter=',')
sorted_indices = np.argsort(recall_new)
recall_new = recall_new[sorted_indices]
precision_new = precision_new[sorted_indices]
precision_new = np.insert(precision_new, 0, 0.0)
recall_new = np.insert(recall_new, 0, 0.0)
AUPR = auc(recall_new, precision_new)
AUPR2 = auc(recall_new2, precision_new2)
AUPR3 = auc(recall_new3, precision_new3)
print("recall_new:", recall_new)
print("precision_new:", precision_new)

# Create and save the first AUPR curve
plt.figure(figsize=(6, 6))
plt.plot(recall_new, precision_new,'--', lw=2, label='OUR Method AUPR={:.4f}'.format(AUPR), color='#5CC4AA')
plt.plot(recall_new2, precision_new2, '--',lw=2, label='DeepEP AUPR={:.4f}'.format(AUPR2), color='#f2cf44')
plt.plot(recall_new3, precision_new3, '--',lw=2, label='MBIEP AUPR={:.4f}'.format(AUPR3), color='#fd9490')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision/Recall Curve')
plt.legend(loc='lower left', bbox_to_anchor=(0.0, 0.0))
plt.tight_layout()
plt.axis('square')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.show()
