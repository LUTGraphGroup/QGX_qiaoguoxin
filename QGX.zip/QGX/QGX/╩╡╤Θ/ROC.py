from sklearn.metrics import auc
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

# Load data
ymips_mean_fpr0 = np.loadtxt('ymips_mean_fpr.csv', delimiter=',')
ymips_mean_tpr0 = np.loadtxt('ymips_mean_tpr.csv', delimiter=',')
ydip_mean_fpr0 = np.loadtxt('ydip_mean_fpr.csv', delimiter=',')
ydip_mean_tpr0 = np.loadtxt('ydip_mean_tpr.csv', delimiter=',')
mean_fpr0 = np.loadtxt('mean_fpr.csv', delimiter=',')
mean_tpr0 = np.loadtxt('mean_tpr.csv', delimiter=',')

# Calculate AUC
ymips_mean_auc0 = auc(ymips_mean_fpr0, ymips_mean_tpr0)
ydip_mean_auc0 = auc(ydip_mean_fpr0, ydip_mean_tpr0)
mean_auc0 = auc(mean_fpr0, mean_tpr0)

lw = 1
plt.rcParams['font.size'] = 10

# Create main figure
fig, ax = plt.subplots(figsize=[6, 6])
ax.plot(ymips_mean_fpr0, ymips_mean_tpr0, '--', color='#FF6F6F', lw=2,
        label='ROC YMIPS (AUC = %0.4f)' % ymips_mean_auc0)
ax.plot(ydip_mean_fpr0, ydip_mean_tpr0, '--', color='#7CA4FF', lw=2,
        label='ROC YDIP (AUC = %0.4f)' % ydip_mean_auc0)
ax.plot(mean_fpr0, mean_tpr0, '--', color='#9ADA52', lw=2,
        label='ROC BioGRID (AUC = %0.4f)' % mean_auc0)
ax.plot([0, 1], [0, 1], color='grey', linestyle='--')
ax.set_xlabel('False Positive Rate')
ax.set_ylabel('True Positive Rate')
ax.set_title('ROC curve')
ax.legend(loc="lower right")

# Create inset_axes with the bounding box [0.5, 0.2, 0.4, 0.4]
axins = inset_axes(ax, width='40%', height='20%', loc='lower left')
axins.plot(ymips_mean_fpr0, ymips_mean_tpr0, '--', color='#8dafac', lw=2,
           label='ROC YMIPS (AUC = %0.4f)' % ymips_mean_auc0)
axins.plot(ydip_mean_fpr0, ydip_mean_tpr0, '--', color='#7CA4FF', lw=2,
           label='ROC YDIP (AUC = %0.4f)' % ydip_mean_auc0)
axins.plot(mean_fpr0, mean_tpr0, '--', color='#9ADA52', lw=2,
           label='ROC BioGRID (AUC = %0.4f)' % mean_auc0)
axins.set_xlim(0,1)
axins.set_ylim(0.7, 1.0)



plt.savefig("ROC_with_inset.pdf", dpi=300)
plt.show()
