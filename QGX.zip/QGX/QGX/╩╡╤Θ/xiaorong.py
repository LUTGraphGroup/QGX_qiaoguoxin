from sklearn.metrics import auc
import numpy as np
import matplotlib.pyplot as plt

# Load data
ymips_mean_fpr0 = np.loadtxt('mean_fpr_ppi.csv', delimiter=',')
ymips_mean_tpr0 = np.loadtxt('mean_tpr_ppi.csv', delimiter=',')
ydip_mean_fpr0 = np.loadtxt('mean_fpr_gene.csv', delimiter=',')
ydip_mean_tpr0 = np.loadtxt('mean_tpr_gene.csv', delimiter=',')
mean_fpr0 = np.loadtxt('mean_fpr.csv', delimiter=',')
mean_tpr0 = np.loadtxt('mean_tpr.csv', delimiter=',')

# Calculate AUC
ymips_mean_auc0 = auc(ymips_mean_fpr0, ymips_mean_tpr0)
ydip_mean_auc0 = auc(ydip_mean_fpr0, ydip_mean_tpr0)
mean_auc0 = auc(mean_fpr0, mean_tpr0)

# Set line width
lw =2

# Create main figure
fig, ax = plt.subplots(figsize=[6,6])  # Adjust the size of the figure
ax.plot(mean_fpr0, mean_tpr0, '--', color='#369F2D', lw=lw,
        label='ROC our method (AUC = %0.4f)' % mean_auc0)
ax.plot(ymips_mean_fpr0, ymips_mean_tpr0, '--', color='#8481DA', lw=lw,
        label='PPI ROC (AUC = %0.4f)' % ymips_mean_auc0)
ax.plot(ydip_mean_fpr0, ydip_mean_tpr0, '--', color='#FC8002', lw=lw,
        label='GENE ROC (AUC = %0.4f)' % ydip_mean_auc0)

ax.plot([0, 1], [0, 1], color='grey', linestyle='--')
ax.set_xlabel('False Positive Rate')
ax.set_ylabel('True Positive Rate')
ax.set_title('ROC curve')
ax.legend(loc="lower right")

# Set the plot to be a square
plt.axis('square')

plt.savefig("ROC.pdf", dpi=300)
plt.show()
precision_new = np.loadtxt('Precision_1.txt', delimiter=',')
recall_new = np.loadtxt('Recall_1.txt', delimiter=',')
precision_new2 = np.loadtxt('Precision_gene1.txt', delimiter=',')
recall_new2 = np.loadtxt('Recall_gene1.txt', delimiter=',')
precision_new3 = np.loadtxt('Precision_ppi0.txt', delimiter=',')
recall_new3 = np.loadtxt('Recall_ppi0.txt', delimiter=',')
sorted_indices = np.argsort(recall_new)
recall_new = recall_new[sorted_indices]
precision_new = precision_new[sorted_indices]
precision_new = np.insert(precision_new, 0, 0.0)
recall_new = np.insert(recall_new, 0, 0.0)
AUPR = auc(recall_new, precision_new)
AUPR2 = auc(recall_new2, precision_new2)
AUPR3 = auc(recall_new3, precision_new3)
print("recall_new:", recall_new)
print("precision_new:", precision_new)


fig, ax = plt.subplots(figsize=[6,6])  # Adjust the size of the figure

ax.plot(recall_new, precision_new,'--', lw=2, label='OUR Method AUPR={:.4f}'.format(auc(recall_new, precision_new)), color='#369F2D')
ax.plot(recall_new2, precision_new2,'--', lw=2, label='Gene AUPR={:.4f}'.format(auc(recall_new2, precision_new2)), color='#8481DA')
ax.plot(recall_new3, precision_new3,'--', lw=2, label='PPI AUPR={:.4f}'.format(auc(recall_new3, precision_new3)), color='#FC8002')


ax.set_xlabel('Recall')
ax.set_ylabel('Precision')
ax.set_title('Precision/Recall Curve')
ax.legend(loc="lower right")

# Set the plot to be a square
plt.axis('square')
plt.xlim([0, 1])  # 将 x 轴坐标范围设置为0到1的范围
plt.ylim([0, 1])
plt.savefig("ROC.pdf", dpi=300)
plt.show()
