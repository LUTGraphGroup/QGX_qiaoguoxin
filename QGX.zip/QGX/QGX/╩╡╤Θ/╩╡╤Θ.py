import time
import numpy as np
from matplotlib import pyplot as plt, pyplot
from sklearn import metrics
from sklearn.metrics import precision_recall_curve, auc, roc_curve, precision_score, recall_score, f1_score, accuracy_score
from keras import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.optimizers import SGD, Adadelta
from keras.utils import to_categorical
from sklearn.model_selection import KFold
from sklearn.utils import shuffle
from sklearn.metrics import confusion_matrix

def get_data(data_path):         #用于从指定路径的文件中读取数据
    with open(data_path, 'r') as f:
        lines = f.readlines()
        feature = np.zeros((len(lines), 134), dtype=np.float64)
        label = np.zeros(len(lines))
        for i, line in enumerate(lines):
            line = line.strip().split('\t')
            feature[i] = list(map(np.float64, line[:-1]))
            label[i] = float(line[-1])
    return feature, label      #该函数返回特征标签和向量

def get_train_data():          #用于读取训练数据
    data_path = 'feature.txt'
    total_sample, label = get_data(data_path)
    return total_sample, label

def DNN():                #定义模型
    model = Sequential()
    model.add(Dense(input_dim=134, output_dim=1024))
    model.add(Activation('relu'))
    model.add(Dropout(0.1))

    model.add(Dense(input_dim=1024, output_dim=652))
    model.add(Activation('relu'))
    model.add(Dropout(0.1))
    model.add(Dense(input_dim=652, output_dim=300))
    model.add(Activation('relu'))
    model.add(Dropout(0.1))

    model.add(Dense(input_dim=300, output_dim=2))
    model.add(Activation('sigmoid'))
    adadelta = Adadelta(lr=0.4 ,rho=0.90, epsilon=1e-08)
    model.compile(loss='binary_crossentropy', optimizer=adadelta)
    # sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
    # model.compile(loss='categorical_crossentropy', optimizer=sgd)
    return model


def train(X, Y):        #用于训练神经网络和模型评估
    X, Y = shuffle(X, Y, random_state=64)
    model_DNN = DNN()
    # clf = XGBClassifier(n_estimators=10000, learning_rate=0.1, random_state=200)
    kf = KFold(n_splits=5)
    print('-----------------------------------------------')
    t = 0
    mean_tpr = 0.0

    mean_fpr = np.linspace(0, 1, 1092)


    AUC_list = []
    AUPRC_list = []
    Accuracy_list = []
    Precision_list = []
    Recall_list = []
    F1_list = []
    confusion_matrices = []

    for train_index, test_index in kf.split(X, Y):
        X_train = X[train_index]
        Y_train = Y[train_index]
        X_test = X[test_index]
        Y_test = Y[test_index]


        Y_train = to_categorical(Y_train)
        Y_test = to_categorical(Y_test)
        # clf.fit(X_train, Y_train)
        # predict_value = clf.predict_proba(X_test)[:, 1]
        model_DNN.fit(X_train, Y_train, batch_size=16, epochs=200, shuffle=True)
        predict_value = model_DNN.predict_proba(X_test, batch_size=16, verbose=True)[:, 1]
        AUC = metrics.roc_auc_score(Y_test[:, 1], predict_value)
        AUC_list.append(AUC)
        fpr, tpr, _ = roc_curve(Y_test[:, 1], predict_value)
        auc_score = auc(fpr, tpr)
        Precision, Recall, _ = precision_recall_curve(Y_test[:, 1], predict_value)
        # Ensure Precision and Recall are sorted
        sorted_indices = np.argsort(Recall)
        Precision = Precision[sorted_indices]
        Recall = Recall[sorted_indices]

        np.savetxt(f'Precision_{t}.txt', Precision)
        np.savetxt(f'Recall_{t}.txt', Recall)
        AUPRC = auc(Recall, Precision)  # Use sorted Precision and Recall
        AUPRC_list.append(AUPRC)
        print(AUPRC_list)
        np.savetxt(f'Precision_{t}.csv', np.column_stack((Recall, Precision)), delimiter=',', header='Recall,Precision',
                   comments='')
        np.savetxt(f'Recall_{t}.csv', Recall, delimiter=',', header='Recall', comments='')

        A = accuracy_score(Y_test[:, 1], predict_value.round())
        Accuracy_list.append(A)
        P = precision_score(Y_test[:, 1], predict_value.round())
        Precision_list.append(P)
        R = recall_score(Y_test[:, 1], predict_value.round())
        Recall_list.append(R)
        F1 = f1_score(Y_test[:, 1], predict_value.round())
        F1_list.append(F1)
        # 计算混淆矩阵
        cm = confusion_matrix(Y_test[:, 1], predict_value.round())
        confusion_matrices.append(cm)
        t += 1
        np.savetxt("fpr_" + str(t) + ".txt", fpr)
        np.savetxt("tpr_" + str(t) + ".txt", tpr)


        # plt.plot(fpr, tpr, linewidth=1, alpha=0.5, label='ROC fold %d (AUC = %0.4f)' % (t, auc_score))
        mean_tpr += np.interp(mean_fpr, fpr, tpr)

        mean_tpr[0] = 0.0



    mean_precision = sum(Precision) / len(Precision)
   # 计算并打印SN、SP、PPV、NPV、F1值
    sensitivities = []
    specificities = []
    positive_predictive_values = []
    negative_predictive_values = []
    f1_scores = []
    for cm in confusion_matrices:
        TP, FN, FP, TN = cm.ravel()

        sensitivity = TP / (TP + FN)
        specificity = TN / (TN + FP)
        ppv = TP / (TP + FP)
        npv = TN / (TN + FN)
        f1 = 2 * (ppv * sensitivity) / (ppv + sensitivity)
        sensitivities.append(sensitivity)
        specificities.append(specificity)
        positive_predictive_values.append(ppv)
        negative_predictive_values.append(npv)
        f1_scores.append(f1)
    mean_tpr /= kf.n_splits

    mean_tpr[-1] = 1.0

    mean_auc = auc(mean_fpr, mean_tpr)

    pyplot.plot(mean_fpr, mean_tpr , 'black', linewidth=1.5, alpha=0.8,
                label='Mean ROC(AUC = %0.4f)' % mean_auc)


    pyplot.legend()

    plt.savefig('5-fold CV protein(AUC = %0.4f).png' % mean_auc, dpi=300)
    pyplot.show()
    # 保存每一折的fpr和tpr数据
    np.savetxt('mean_fpr.csv', mean_fpr, delimiter=',')
    np.savetxt('mean_tpr.csv', mean_tpr, delimiter=',')




    print("AUC average is", sum(AUC_list) / len(AUC_list))
    print("AUPRC average is", sum(AUPRC_list) / len(AUPRC_list))
    pyplot.plot(Recall, Precision, 'black', linewidth=1.5, alpha=0.8,
                label='Mean ROC(AUPRC = %0.4f)' % AUPRC)
    pyplot.legend()
    plt.savefig('1-fold CV protein(AUPRC = %0.4f).png' % AUPRC, dpi=300)
    pyplot.show()
    print("the average of Accuracy is ", sum(Accuracy_list) / len(Accuracy_list))
    print("the average of Precision is ", sum(Precision_list) / len(Precision_list))
    print("the average of Recall is ", sum(Recall_list) / len(Recall_list))
    # print("the average of F1 is ", sum(F1_list) / len(F1_list))
    # 打印计算的评估指标的平均值
    print("Average Sensitivity (SN):", sum(sensitivities) / len(sensitivities))
    print("Average Specificity (SP):", sum(specificities) / len(specificities))
    print("Average Positive Predictive Value (PPV):", sum(positive_predictive_values) / len(positive_predictive_values))
    print("Average Negative Predictive Value (NPV):", sum(negative_predictive_values) / len(negative_predictive_values))
    print("Average F1 Score (F1):", sum(f1_scores) / len(f1_scores))


if __name__ == "__main__":
    sample_data, lable = get_train_data()
    sample_data = np.array(sample_data)
    lable = np.array(lable)

    time_start = time.time()
    train(sample_data, lable)
    time_end = time.time()
    print('time cost', time_end - time_start, 's')
